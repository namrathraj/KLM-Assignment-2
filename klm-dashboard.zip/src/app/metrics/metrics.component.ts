import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material';
import { RestApiService } from '../shared/rest-api.service';
import { calcPossibleSecurityContexts } from '@angular/compiler/src/template_parser/binding_parser';
@Component({
  selector: 'app-metrics',
  templateUrl: './metrics.component.html',
  styleUrls: ['./metrics.component.css']
})
export class MetricsComponent implements OnInit {
  serviceObject: any[] = [];
  serviceObjectCount: any[] = [];
  serviceObjectSum: any[] = [];
  responseStatusCount: any = {};
  responseStatusSum: any = {};
  avrresponseTime: number = 0;
  minresponseTime: number = 0;
  maxresponseTime: number = 0;
  totalReqcount: number = 0;

  constructor(public restApiService: RestApiService) {
    this.restApiService.getTrace().subscribe((data: any) => {
      let result: any[] = data.split("\n");
      result = result.filter((value, index, arry) => {
        if (value.indexOf("http_response_time_milliseconds{") != -1) {
          let Obj: any = getServiceObj(value, "normal");
          if (this.minresponseTime != 0) {
            if (Obj.responsetime != 0) {
              if (parseInt(Obj.responsetime) < this.minresponseTime) {
                this.minresponseTime = parseInt(Obj.responsetime);
              }
            }
          } else {
            this.minresponseTime = parseInt(Obj.responsetime);
          }
          this.maxresponseTime = (Obj.responsetime > this.maxresponseTime) ? Obj.responsetime : this.maxresponseTime;
          this.serviceObject.push(Obj);
          return true;
        } else if (value.indexOf("http_response_time_milliseconds_count{") != -1) {
          this.serviceObjectCount.push(getServiceObj(value, "count"));
          return true;
        } else if (value.indexOf("http_response_time_milliseconds_sum{") != -1) {
          this.serviceObjectSum.push(getServiceObj(value, "sum"));
          return true;
        }
        return false;
      });
      this.responseStatusCount = countCals(this.serviceObjectCount);
      this.responseStatusSum = calSum(this.serviceObjectSum);
      this.totalReqcount = calcTotalRes(this.responseStatusCount);
      this.avrresponseTime = parseInt(this.responseStatusSum) / this.totalReqcount;
      this.avrresponseTime = parseFloat(this.avrresponseTime.toFixed(2));
      if (this.minresponseTime == 0) {
        this.minresponseTime = this.avrresponseTime;
      }
      if (this.maxresponseTime == 0 || this.maxresponseTime < this.avrresponseTime) {
        this.maxresponseTime = this.avrresponseTime;
      }
    });
  }
  ngOnInit() {
  }
}
function getServiceObj(value: any, type: any): any {
  let statusTitle = "status=";
  let handlerTitle = "handler=";
  let tempVal: any[] = value.split(",");
  var serviceObj: any = {};
  tempVal.forEach((data) => {
    if (data.indexOf(statusTitle) != -1) {
      serviceObj.status = data.substring(data.indexOf("=") + 2, data.length - 1);
    } else if (data.indexOf(handlerTitle) != -1) {
      serviceObj.handler = data.substring(data.indexOf("=") + 2, data.length - 1);
    }
  });
  if (type == "normal") {
    serviceObj.responsetime = (value.substring(value.indexOf("}") + 1, value.length)).trim();
    if (isNaN(serviceObj.responsetime)) {
      serviceObj.responsetime = 0;
    }
  } else if (type == "count") {
    serviceObj.count = (value.substring(value.indexOf("}") + 1, value.length)).trim();
  } else if (type == "sum") {
    serviceObj.sum = (value.substring(value.indexOf("}") + 1, value.length)).trim();
  }
  return serviceObj;
}
function countCals(countArr: any) {
  let responseStatusCount: any = {};
  for (var i = 0; i < countArr.length; i++) {
    if (parseInt(countArr[i].status) >= 200 && parseInt(countArr[i].status) < 300) {
      if (responseStatusCount["2"]) {
        responseStatusCount["2"] = responseStatusCount["2"] + parseInt(countArr[i].count);
      } else {
        responseStatusCount["2"] = parseInt(countArr[i].count);
      }
    } else if (parseInt(countArr[i].status) >= 400 && parseInt(countArr[i].status) < 500) {
      if (responseStatusCount["4"]) {
        responseStatusCount["4"] = responseStatusCount["4"] + parseInt(countArr[i].count);
      } else {
        responseStatusCount["4"] = parseInt(countArr[i].count);
      }
    } else if (parseInt(countArr[i].status) >= 500 && parseInt(countArr[i].status) < 600) {
      if (responseStatusCount["5"]) {
        responseStatusCount["5"] = responseStatusCount["5"] + parseInt(countArr[i].count);
      } else {
        responseStatusCount["5"] = parseInt(countArr[i].count);
      }
    }
  }
  return responseStatusCount;
}
function calSum(arr: any[]) {
  let total: any = 0;
  for (var i = 0; i < arr.length; i++) {
    total += parseInt(arr[i].sum);
  }
  return total;
}
function calcTotalRes(obj: any) {
  let count: number = 0;
  if (obj["2"]) {
    count += parseInt(obj["2"]);
  }
  if (obj["4"]) {
    count += parseInt(obj["4"]);
  }
  if (obj["5"]) {
    count += parseInt(obj["5"]);
  }
  return count;
}