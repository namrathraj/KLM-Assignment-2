import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'klm-dashboard';
  navLinks: any[];
  activeLinkIndex = -1; 
  constructor(private router:Router){
    this.navLinks = [
      {
          label: 'Fare Details',
          link: './fare',
          index: 0
      }, {
          label: 'Metrics',
          link: './metrics',
          index: 1
      }, {
          label: 'Airports',
          link: './airports',
          index: 2
      }, 
  ];
  }
  ngOnInit(): void {
    this.router.events.subscribe((res) => {
        this.activeLinkIndex = this.navLinks.indexOf(this.navLinks.find(tab => tab.link === '.' + this.router.url));
    });
  }
}

