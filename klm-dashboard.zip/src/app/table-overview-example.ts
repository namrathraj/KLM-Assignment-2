import {Component, ViewChild, OnInit} from '@angular/core';
import {MatPaginator, MatSort, MatTableDataSource} from '@angular/material';
import { RestApiService } from './shared/rest-api.service';
 
@Component({
  selector: 'table-overview-example',
  styleUrls: ['table-overview-example.css'],
  templateUrl: 'table-overview-example.html',
})
export class TableOverviewExample implements OnInit{
  displayedColumns = ['code','name','description'];
  dataSource: MatTableDataSource<Aiptort>;
    public pageSize = 5;
    public currentPage = 0;
    public totalSize = 0;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(public restApiService:RestApiService) {    
    console.log("Constructor called");
  }
  ngOnInit(){
    console.log("ngOnInit called");
    this.restApiService.getAllAirportDetails().subscribe((data:any)=>{
        this.dataSource = new MatTableDataSource(data);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
    });
  }
  ngAfterViewInit() {
        console.log("ngAfterViewInit called");
  }

  applyFilter(filterValue: string) {
    filterValue = filterValue.trim();  
    filterValue = filterValue.toLowerCase();  
    this.dataSource.filter = filterValue;
  }
}

export interface Aiptort {
    code: string;
    name:string;
    description: string;
  }
 