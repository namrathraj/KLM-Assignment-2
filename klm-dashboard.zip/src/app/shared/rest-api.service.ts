import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class RestApiService {

  apiURL = 'http://localhost:8000';
  traceURL = 'http://localhost:8000';
  constructor(private http: HttpClient) {

  }
  getAirportDetails(term): Observable<any> {
    return this.http.get(this.apiURL + '/getAllAirports/' + term)
      .pipe(
        retry(1),
        catchError(this.handleError)
      )
  }
  getAllAirportDetails(): Observable<any> {
    return this.http.get(this.apiURL + '/getAllAirports')
      .pipe(
        retry(1),
        catchError(this.handleError)
      )
  }
  getFares(from: any, to: any): Observable<any> {
    return this.http.get(this.apiURL + '/fares/' + from + "/" + to)
      .pipe(
        retry(1),
        catchError(this.handleError)
      )
  }
  getTrace(): Observable<any> {


    return this.http.get(this.traceURL + "/getTrace?t=" + Date.now(), { responseType: 'text' })
      .pipe(
        retry(1),
        catchError(this.handleError)
      )
  }

  handleError(error) {
    let errorMessage = '';
    if (error.error instanceof ErrorEvent) {
      // Get client-side error
      errorMessage = error.error.message;
    } else {
      // Get server-side error
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    console.log(errorMessage);
    return throwError(errorMessage);
  }
}
