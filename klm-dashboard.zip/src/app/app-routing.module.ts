import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { FareComponent } from './fare/fare.component';
import { AirportsComponent } from './airports/airports.component';
import { MetricsComponent } from './metrics/metrics.component';
import { NgSelectModule } from '@ng-select/ng-select';
import { TableOverviewExample } from './table-overview-example';

const routes: Routes = [
  { path: '', redirectTo: '/fare', pathMatch: 'full' },
  { path: 'fare', component:  FareComponent},
  { path: 'metrics', component:  MetricsComponent},
  { path: 'airports', component: AirportsComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
