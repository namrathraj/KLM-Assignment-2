import { Component, OnInit, NgModule } from '@angular/core';
import { RestApiService } from '../shared/rest-api.service';
import { TableOverviewExample } from '../table-overview-example';

@Component({
  selector: 'app-airports',
  templateUrl: './airports.component.html',
  styleUrls: ['./airports.component.css']
})
@NgModule({
  imports: [],
  exports: [TableOverviewExample],
  declarations: [TableOverviewExample],
  providers: [],
})
export class AirportsComponent implements OnInit {
    constructor(public restApiService:RestApiService){
    }
    ngOnInit() {
    }
   
   
 } 
