import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { RestApiService } from "../shared/rest-api.service";
import { checkAndUpdateBinding } from '@angular/core/src/view/util';
import {NgOption} from "@ng-select/ng-select";

@Component({
  selector: 'app-fare',
  templateUrl: './fare.component.html',
  styleUrls: ['./fare.component.css']
})
export class FareComponent implements OnInit {
  fromCity:Airport;
  toCity:Airport;
  fromairports:Airport[]=[];
  toairports:Airport[] = [];
  fare:any;
  constructor(public restApiService:RestApiService) {
       
  }

  ngOnInit() {
  }
 
  bringFromAirports(evt:any){
      let param = evt.target.value;; 
     console.log(param);
       this.restApiService.getAirportDetails(param).subscribe((data: Airport[]) => {
         this.fromairports = data;
     });
  }
  bringToAirports(evt:any){
    let param = evt.target.value;; 
   console.log(param);
     this.restApiService.getAirportDetails(param).subscribe((data: Airport[]) => {
       this.toairports = data;
   });
 }
 selectAirport(){
    if(this.fromCity && undefined!=this.fromCity.code && ""!=this.fromCity.code && this.toCity && undefined!=this.toCity.code 
                                                                                   && ""!=this.toCity.code){
          this.restApiService.getFares(this.fromCity.code,this.toCity.code).subscribe((data:any) => {
              this.fare = data.amount + " "+data.currency; 
          });
     }
 } 

}
 interface Airport {
    code:string;
    name:string;
    description:string;
}