package com.klm.exercises.dashboard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.security.SecurityAutoConfiguration;

@SpringBootApplication(exclude = SecurityAutoConfiguration.class)
public class KLMAppBootStrap {

	public static void main(String[] args) {
		SpringApplication.run(KLMAppBootStrap.class, args);
	}
}
