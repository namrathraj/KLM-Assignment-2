package com.klm.exercises.dashboard.services;


import static org.springframework.web.bind.annotation.RequestMethod.GET;

import java.io.ObjectOutputStream.PutField;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Arrays;
import java.util.function.Consumer;

import org.eclipse.jetty.http.HttpStatus;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.boot.json.JsonParser;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

 
@CrossOrigin(origins = "http://localhost:4200", maxAge = 3600)
@RestController
 
public class KLMController {

    
    private String getAccessToken() throws ParseException{
    	String url = "http://localhost:9000/oauth/token";
    	RestTemplate restTemplate = new RestTemplate();
    	HttpHeaders headers = new HttpHeaders();
    	String request = "grant_type=client_credentials";
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.set("Authorization", "Basic dHJhdmVsLWFwaS1jbGllbnQ6cHN3");
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        HttpEntity  entity = new HttpEntity(request, headers);   
        ResponseEntity  responseEntity = restTemplate.exchange(url, HttpMethod.POST, entity,String.class)  ; 
        JSONParser parser = new JSONParser(); 
        org.json.simple.JSONObject json = (org.json.simple.JSONObject) parser.parse(responseEntity.getBody().toString()); 
        String accessToken = json.get("token_type")+" "+json.get("access_token");
        return  accessToken;
    }
 
    @RequestMapping(value="/getAllAirports/{term}",method = GET)
    @ResponseBody
    private org.json.simple.JSONArray getAllAirportDetailsTerm(@PathVariable("term") String term) throws ParseException, URISyntaxException{
    	
    	org.json.simple.JSONArray rawArr = new org.json.simple.JSONArray(); 
    	org.json.simple.JSONArray resultArr = new org.json.simple.JSONArray(); 
    	
    	String url = "http://localhost:9000/airports?term="+term;
    	URI uri = new URI(url);
    	RestTemplate restTemplate = new RestTemplate();
    	HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", getAccessToken());
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity  entity = new HttpEntity(null,headers);
        ResponseEntity  responseEntity = restTemplate.exchange(url, HttpMethod.GET, entity,   String.class)  ; 
        JSONParser parser = new JSONParser(); 
        org.json.simple.JSONObject json = (org.json.simple.JSONObject) parser.parse(responseEntity.getBody().toString()); 
        org.json.simple.JSONObject rootEle  = (org.json.simple.JSONObject) json.get("_embedded");
        if(null!=rootEle.get("locations")){
        	
        	rawArr = ((org.json.simple.JSONArray)rootEle.get("locations"));
        	
        	
        	for(int i = 0;i<rawArr.size();i++){
        		
        		org.json.simple.JSONObject currentObj = new org.json.simple.JSONObject();
        		currentObj.put("code",((org.json.simple.JSONObject)rawArr.get(i)).get("code"));
        		currentObj.put("name",((org.json.simple.JSONObject)rawArr.get(i)).get("name"));
        		currentObj.put("description",((org.json.simple.JSONObject)rawArr.get(i)).get("description"));
        		resultArr.add(currentObj);
        	}
        	
        }
        return resultArr;
    }  
     
    @RequestMapping(value="/getAllAirports",method = GET)
    @ResponseBody
    private org.json.simple.JSONArray getAllAirportDetails() throws ParseException, URISyntaxException{
    	
    	org.json.simple.JSONArray rawArr = new org.json.simple.JSONArray(); 
    	org.json.simple.JSONArray resultArr = new org.json.simple.JSONArray(); 
    	
    	String url = "http://localhost:9000/airports";
    	URI uri = new URI(url);
    	RestTemplate restTemplate = new RestTemplate();
    	HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", getAccessToken());
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity  entity = new HttpEntity(null,headers);
        ResponseEntity  responseEntity = restTemplate.exchange(url, HttpMethod.GET, entity,   String.class)  ; 
        JSONParser parser = new JSONParser(); 
        org.json.simple.JSONObject json = (org.json.simple.JSONObject) parser.parse(responseEntity.getBody().toString()); 
        org.json.simple.JSONObject rootEle  = (org.json.simple.JSONObject) json.get("_embedded");
        if(null!=rootEle.get("locations")){
        	
        	rawArr = ((org.json.simple.JSONArray)rootEle.get("locations"));
        	
        	
        	for(int i = 0;i<rawArr.size();i++){
        		
        		org.json.simple.JSONObject currentObj = new org.json.simple.JSONObject();
        		currentObj.put("code",((org.json.simple.JSONObject)rawArr.get(i)).get("code"));
        		currentObj.put("name",((org.json.simple.JSONObject)rawArr.get(i)).get("name"));
        		currentObj.put("description",((org.json.simple.JSONObject)rawArr.get(i)).get("description"));
        		resultArr.add(currentObj);
        	}
        	
        }
        return resultArr;
    }
    

	@RequestMapping(value = "/fares/{from}/{to}", method = GET)
    @ResponseBody
    public org.json.simple.JSONObject getFare(@PathVariable("from") String from,@PathVariable("to") String to) throws ParseException, URISyntaxException{
    	
    	String url = "http://localhost:9000/fares/"+from+"/"+to;
    	URI uri = new URI(url);
    	RestTemplate restTemplate = new RestTemplate();
    	HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", getAccessToken());
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        HttpEntity  entity = new HttpEntity(null,headers);
        ResponseEntity  responseEntity = restTemplate.exchange(url, HttpMethod.GET, entity,   String.class)  ; 
        JSONParser parser = new JSONParser(); 
        org.json.simple.JSONObject json = (org.json.simple.JSONObject) parser.parse(responseEntity.getBody().toString()); 
    	return json;
    }
	
	@RequestMapping(value="/getTrace",method = GET)
    @ResponseBody
    private String getTrace() throws ParseException, URISyntaxException{
    	
    	org.json.simple.JSONArray rawArr = new org.json.simple.JSONArray(); 
    	org.json.simple.JSONArray resultArr = new org.json.simple.JSONArray(); 
    	
    	String url = "http://localhost:8000/metrics";
    	URI uri = new URI(url);
    	RestTemplate restTemplate = new RestTemplate();
    	HttpHeaders headers = new HttpHeaders();
        
        HttpEntity  entity = new HttpEntity(null,headers);
        ResponseEntity  responseEntity = restTemplate.exchange(url, HttpMethod.GET, entity,   String.class)  ; 
        JSONParser parser = new JSONParser(); 
        return responseEntity.getBody().toString();
    }

	
}